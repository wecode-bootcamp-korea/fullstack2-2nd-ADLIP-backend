const fs = require('fs');
const csv = require('csv-parser');
const { PrismaClient } = require('@prisma/client');
const { resolve } = require('path');
const prisma = new PrismaClient();

const createMainCategory = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/mainCategories.csv`)
      .pipe(csv())
      .on('data', async mainCategory => {
        try {
          await prisma.$queryRaw`
        INSERT INTO main_categories (id, main_category_name, main_category_image_url) VALUES (${mainCategory.id}, ${mainCategory.main_category_name}, ${mainCategory.main_category_image_url});
        `;
          console.log('mainCategory data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        console.log('test');
        prisma.$disconnect();
      });
  });
};

const createSubCategory = async () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/subCategories.csv`)
      .pipe(csv())
      .on('data', async subCategories => {
        try {
          await prisma.$queryRaw`
          INSERT INTO sub_categories (sub_category_name, main_category_id) VALUES (${subCategories.sub_category_name}, ${subCategories.main_category_id});
          `;
          console.log('subCategory data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createMonthlyThemeProduct = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/monthlyThemeProducts.csv`)
      .pipe(csv())
      .on('data', async monthlyThemeProduct => {
        try {
          await prisma.$queryRaw`
        INSERT INTO monthly_theme_products (id) VALUES (${monthlyThemeProduct.id});
        `;
          console.log('monthlyThemeProducts data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createLimitedPeriodDiscountProduct = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/limitedPeriodDiscountProducts.csv`)
      .pipe(csv())
      .on('data', async limitedPeriodDiscountProduct => {
        try {
          await prisma.$queryRaw`
      INSERT INTO limited_period_discount_products (id, period_discount_rate, start_at, finish_at) VALUES (${limitedPeriodDiscountProduct.id}, ${limitedPeriodDiscountProduct.period_discount_rate}, ${limitedPeriodDiscountProduct.start_at}, ${limitedPeriodDiscountProduct.finish_at});
      `;
          console.log('limitedPeriodDiscountProduct data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createUpperRegion = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/upperRegions.csv`)
      .pipe(csv())
      .on('data', async upperRegion => {
        try {
          await prisma.$queryRaw`
        INSERT INTO upper_regions (id, name) VALUES (${upperRegion.id}, ${upperRegion.name});
        `;
          console.log('upperRegion data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createLowerRegion = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/lowerRegions.csv`)
      .pipe(csv())
      .on('data', async lowerRegion => {
        try {
          await prisma.$queryRaw`
        INSERT INTO lower_regions (id, name, upper_region_id) VALUES (${lowerRegion.id}, ${lowerRegion.name}, ${lowerRegion.upper_region_id});
        `;
          console.log('lowerRegion data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createParticipantType = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/participantTypes.csv`)
      .pipe(csv())
      .on('data', async participantType => {
        try {
          await prisma.$queryRaw`
        INSERT INTO participant_types (id, name) VALUES (${participantType.id}, ${participantType.name})
        `;
          console.log('participantType data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createUser = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/users.csv`)
      .pipe(csv())
      .on('data', async user => {
        try {
          await prisma.$queryRaw`
        INSERT INTO users (id, email, password, nickname, status, profile_image_url, social_platform) VALUES (${user.id}, ${user.email}, ${user.password}, ${user.nickname}, ${user.status}, ${user.profile_image_url}, ${user.social_platform})
        `;
          console.log('user data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createHost = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/hosts.csv`)
      .pipe(csv())
      .on('data', async host => {
        try {
          await prisma.$queryRaw`
        INSERT INTO hosts (id, account, user_id) VALUES (${host.id}, ${host.account}, ${host.user_id});
        `;
          console.log('host data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createEnquery = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/enqueries.csv`)
      .pipe(csv())
      .on('data', async enquery => {
        try {
          await prisma.$queryRaw`
          INSERT INTO enqueries (id, enquery_text, is_private, product_id, user_id, reply_id) VALUES (${
            enquery.id
          }, ${enquery.enquery_text}, ${enquery.is_private}, ${
            enquery.product_id
          }, ${enquery.user_id}, ${parseInt(enquery.reply_id)});
          `;
          console.log('enquery data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createOrder = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/orders.csv`)
      .pipe(csv())
      .on('data', async order => {
        try {
          await prisma.$queryRaw`
        INSERT INTO orders (id, user_id) VALUES (${order.id}, ${order.user_id});
        `;
          console.log('order data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createProduct = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/products.csv`)
      .pipe(csv())
      .on('data', async product => {
        try {
          await prisma.$queryRaw`
          INSERT INTO products (id, name, price, summary, main_image_url, discount_rate, is_only, is_new, location, start_at, finish_at, main_category_id, sub_category_id, host_id, upper_region_id, lower_region_id, participant_type_id, monthly_theme_product_id, limited_period_discount_product_id) VALUES (${
            product.id
          }, ${product.name}, ${product.price}, ${product.summary}, ${
            product.main_image_url
          }, ${product.discount_rate}, ${product.is_only}, ${product.is_new}, ${
            product.location
          }, ${product.start_at}, ${product.finish_at}, ${
            product.main_category_id
          }, ${product.sub_category_id}, ${product.host_id}, ${
            product.upper_region_id
          }, ${parseInt(product.lower_region_id)}, ${
            product.participant_type_id
          }, ${parseInt(product.monthly_theme_product_id)}, ${parseInt(
            product.limited_period_discount_product_id,
          )});
          `;
          console.log('product data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createProductDetail = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/productDetails.csv`)
      .pipe(csv())
      .on('data', async productDetail => {
        try {
          await prisma.$queryRaw`
        INSERT INTO product_details (id, place_of_progress_latitude, place_of_progress_longitude, place_of_progress, gathering_place_latitude, gathering_place_longitude, gathering_place, expired_day, introduction, product_id) VALUES (${productDetail.id}, ${productDetail.place_of_progress_latitude}, ${productDetail.place_of_progress_longitude}, ${productDetail.place_of_progress}, ${productDetail.gathering_place_latitude}, ${productDetail.gathering_place_longitude}, ${productDetail.gathering_place}, ${productDetail.expired_day}, ${productDetail.introduction}, ${productDetail.product_id});
        `;
          console.log('productDetail data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createProductOrder = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/productsOrders.csv`)
      .pipe(csv())
      .on('data', async productOrder => {
        try {
          await prisma.$queryRaw`
        INSERT INTO products_orders (id, order_id, product_id) VALUES (${productOrder.id}, ${productOrder.order_id}, ${productOrder.product_id});
        `;
          console.log('productOrder data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        prisma.$disconnect();
      });
  });
};

const createComment = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/comments.csv`)
      .pipe(csv())
      .on('data', async comment => {
        try {
          await prisma.$queryRaw`
            INSERT INTO comments (id, rating, comment_text, order_id, reply_id, product_id) VALUES (${
              comment.id
            }, ${comment.rating}, ${comment.comment_text}, ${
            comment.order_id
          }, ${parseInt(comment.reply_id)},${parseInt(comment.product_id)});
            `;
          console.log('comment data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createProductOption = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/productOptions.csv`)
      .pipe(csv())
      .on('data', async productOption => {
        try {
          await prisma.$queryRaw`
            INSERT INTO product_options (id, name, price, start_at, amount, product_id) VALUES (${productOption.id}, ${productOption.name}, ${productOption.price}, ${productOption.start_at}, ${productOption.amount}, ${productOption.product_id});
            `;
          console.log('productOption data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createCommentImage = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/commentImages.csv`)
      .pipe(csv())
      .on('data', async commentImage => {
        try {
          await prisma.$queryRaw`
        INSERT INTO comment_images (id, comment_image_url, comment_id) VALUES (${commentImage.id}, ${commentImage.comment_image_url}, ${commentImage.comment_id});
        `;
          console.log('commentImage data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createLikeProduct = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/likesProducts.csv`)
      .pipe(csv())
      .on('data', async likeProduct => {
        try {
          await prisma.$queryRaw`
        INSERT INTO likes_products (id, user_id, product_Id) VALUES (${likeProduct.id}, ${likeProduct.user_id}, ${likeProduct.product_id})
      `;
          console.log('likeProcuct data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createLikeHost = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/likesHosts.csv`)
      .pipe(csv())
      .on('data', async likeHost => {
        try {
          await prisma.$queryRaw`
        INSERT INTO likes_hosts (id, user_id, host_id) VALUES (${likeHost.id}, ${likeHost.user_id}, ${likeHost.host_id})
      `;
          console.log('likeHost data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const createLikeComment = () => {
  return new Promise(resolve => {
    fs.createReadStream(`${__dirname}/likesComments.csv`)
      .pipe(csv())
      .on('data', async likeComment => {
        try {
          await prisma.$queryRaw`
        INSERT INTO likes_comments (id, user_id, comment_id) VALUES (${likeComment.id}, ${likeComment.user_id}, ${likeComment.comment_id})
      `;
          console.log('likeComment data load success');
        } catch (error) {
          console.log(error);
        }
      })
      .on('end', async () => {
        resolve();
        prisma.$disconnect();
      });
  });
};

const run = async () => {
  // await createMainCategory();
  // await createSubCategory();
  // await createMonthlyThemeProduct();
  // await createLimitedPeriodDiscountProduct();
  // await createUpperRegion();
  // await createLowerRegion();
  // await createParticipantType();
  // await createUser();
  // await createHost();
  // await createProduct();
  // await createEnquery();
  // await createOrder();
  // await createProductDetail();
  // await createProductOption();
  // await createProductOrder();
  // await createComment();
  // await createCommentImage();
  // await createLikeProduct();
  // await createLikeHost();
  await createLikeComment();
};

run();
